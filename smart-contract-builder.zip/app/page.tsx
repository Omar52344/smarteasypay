"use client"

import SmartContractBuilder from "../smart-contract-builder"

export default function Page() {
  return <SmartContractBuilder />
}
